package tableInstances;

public class Type {
	
}
