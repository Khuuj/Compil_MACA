package tableInstances;

import java.util.ArrayList;

import tableTypes.Method;

public class Classe extends ClassType 
{
	
	public Classe( String id, Classe supClass, ArrayList<Var> attributs, ArrayList<Method> méthodes) {
		super(id);
		this.supClass = supClass;
		this.attributs = attributs;
		this.méthodes = méthodes;
		// TODO Auto-generated constructor stub
	}

}
