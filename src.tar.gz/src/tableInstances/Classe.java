package tableInstances;


public class Classe extends Element 
{
	
	String classId; //identificateur de la classe dont elle est l'instance
	
	public Classe(String id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
