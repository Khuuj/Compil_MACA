package tableInstances;


public class Var extends Element {
	
	String type;
	
	public Var(String id, String type) {
		super(id);
		this.type = type;
	}

}
