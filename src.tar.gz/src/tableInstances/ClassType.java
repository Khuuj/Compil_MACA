package tableInstances;


public abstract class ClassType {
	String id; //identificateur de l'élément
	
	//Si l'élément est une classe
	public ClassType(String id)
	{
		this.id = id;
	}
}
