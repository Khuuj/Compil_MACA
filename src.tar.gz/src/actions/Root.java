package actions;

import org.antlr.runtime.tree.Tree;

public class Root {
	
	public Root(Tree node)
	{
		
	}
}
