package tableTypes;

//Méthode d'une classe
public class Method extends ClassItem {

	public Method(String id) {
		super(id);
	}

}
