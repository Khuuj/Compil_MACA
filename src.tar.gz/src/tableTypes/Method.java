package tableTypes;

import tableInstances.ClassType;

public class Method extends ClassItem {

	public Method(String id) {
		super(id);
	}

}
