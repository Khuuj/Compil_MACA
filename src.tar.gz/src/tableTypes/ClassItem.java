package tableTypes;

import tableInstances.Element;

//Classe représenant soit les attributs soit les méthodes d'une classe
public abstract class ClassItem extends Element{

	public ClassItem(String id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
