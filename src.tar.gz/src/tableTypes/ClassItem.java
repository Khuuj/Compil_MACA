package tableTypes;

import tableInstances.Element;

public abstract class ClassItem extends Element{

	public ClassItem(String id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
