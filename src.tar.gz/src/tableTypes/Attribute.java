package tableTypes;

public class Attribute {

}
